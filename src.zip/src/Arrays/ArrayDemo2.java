package Arrays;

public class ArrayDemo2
{
	public static void main(String[] args) 
	{
		int[] a={5,3,2,4};
		int[] b=new int[a.length];
		int j=0;
		for (int i = a.length -1; i>=0; i--) 
		{
	         b[j]=a[i];
	         j++;
		}
		for (int i = 0; i < b.length; i++) 
		{
			System.out.print(b[i]+" ");
		}
	}

}
