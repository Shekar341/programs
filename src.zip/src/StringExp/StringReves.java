package StringExp;

public class StringReves 
{
	public static void main(String[] args) 
	{
		String st="Rama went to Qspider";
		char[] ch=st.toCharArray();
		String res="";
		for (int i = 0; i < ch.length; i++) 
		{
			int k=i;
			while(i<ch.length&&ch[i]!=' ')
			{
				i++;
			}
			int j=i-1;
			while(j>=k)
			{
				res+=ch[j];
				j--;
			}
			if(i<ch.length&&ch[i]==' ')
			{
				res+=ch[i];
			}
			
		}
		System.out.println(res);
		
	}

}
