import java.util.Scanner;


public class ArmStrongNumber 
{//, 6, 7, 8, 9, 153, 370, 371, 407, 
	//1634, 8208, 9474, 54748, 
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
	   System.out.println("Enter The Number");
		armstrongnum(sc.nextInt());
	}
	private static void armstrongnum(int n) 
	{
		int temp=n;
		int c=count(n);
		int sum=0;
		while(n>0)
		{
			int r=n%10;
			int p=1;
			for (int i = 1; i <=c; i++)
			{
				p=p*r;
			}
			sum=sum+p;
			n=n/10;
		}
		if(sum==temp)
		{
			System.out.println("ArmStrong");
		}
		else
		{
			System.out.println("not ArmStrong");
		}
		
	}

	private static int count(int n) 
	{
		int c=0;
		while(n>0)
		{
			n=n/10;
			c++;
			
		}
		return c;
	}

}
