package StringExp;

public class ReplacevowelsWithStar 
{
	public static void main(String[] args) 
	{
	String st="Hello A Hi You";
	vowelsWithStar(st.toLowerCase());
	}

 static void vowelsWithStar(String st) 
 {
		char[] ch=st.toCharArray();
		for (int i = 0; i < ch.length; i++) 
		{
			if(ch[i]=='a')
			{
				ch[i]='$';
			}
			else if(ch[i]=='e')
				{
				ch[i]='!';
				}
			else if(ch[i]=='i')
			{
			ch[i]='@';
			}
			else if(ch[i]=='o')
				{
				ch[i]='#';
				}
			else if(ch[i]=='u')
			{
			ch[i]='%';
			}
			
		}
		System.out.println(ch);
		
 }

}
