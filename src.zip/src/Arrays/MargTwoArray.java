package Arrays;

public class MargTwoArray 
{
	public static void main(String[] args) 
	{
		int[] a={1,2,3,4,6,6,6,6};
		int[] b={5,6,7,8,9};
		int[] c=new int[a.length+b.length];
		int j=0,k=0;
		for (int i = 0; i < c.length;i++) 
		{
			if(i<a.length&&i<b.length)
			{
				c[k]=a[i];
				 k++;
				c[k]=b[i];
				k++;
				
			}
			else if(i<b.length)
			{
				c[k]=b[i];
				k++;
			}
			else if(i<a.length)
			{
				c[k]=a[i];
				k++;
			}
		}
		for (int i = 0; i < c.length; i++) 
		{
			System.out.print(c[i]+" ");
		}
	}

}
