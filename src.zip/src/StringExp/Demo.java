package StringExp;

public class Demo 
{
	static{
		System.out.println("inside static block");
	}
	
	{
	System.out.println("inside non static block");
	}
	
	public static void main(String[] args) 
	{
		
		System.out.println("inside main method");
		Demo2 d = new Demo2();
		Demo2 d2 = new Demo2();
		
		
	}
}
class Demo2
{
	static
	{
	System.out.println("inside Demo2 static block");
	}
	
	{
	   System.out.println("inside demo2 instance block");
	}
	
	
}

