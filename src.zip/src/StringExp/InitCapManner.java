package StringExp;

public class InitCapManner 
{
public static void main(String[] args) 
{
	String st="WelCome   tO  jSpiDDiii HHH  y7yyder";
	char[] ch=st.toCharArray();
	String res="";
	for (int i = 0; i < ch.length; i++) 
	{
		if(i==0&&ch[i]!=' '||ch[i]!=' '&&ch[i-1]==' ')
		{
			if(ch[i]>='a'&&ch[i]<='z')
			{
				res+=(char)(ch[i]-32);
			}
			else
			{
				res+=ch[i];
			}
			
		}
		else if(ch[i]>='A'&&ch[i]<='Z')
		{
			res+=(char)(ch[i]+32);
		}
		else
		{
			res+=ch[i];
		}
		
	}
	System.out.println(res);
	
}
}
