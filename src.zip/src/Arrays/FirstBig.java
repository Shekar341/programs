package Arrays;

public class FirstBig 
{
	public static void main(String[] args)
	{
		int[] a={11,5,2,8,3,10};
		int fbig =a[0];
		int sbig=a[1];
		for (int i =1; i < a.length; i++) 
		{
		  if(a[i]>fbig)
		  {
			  sbig=fbig;
			  fbig=a[i];
		  }
		else if(a[i]>sbig)
		{
			sbig=a[i];
		}
				
	}
		System.out.println(fbig);
		System.out.println(sbig);
	}

}
