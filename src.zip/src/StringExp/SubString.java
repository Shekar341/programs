package StringExp;

public class SubString
{
	public static void main(String[] args) 
	{
		String main="i love a abe java";
		String sub="a";
		System.out.println(substringChek(main,sub));
		
	}
//		static boolean  subChek(String main,String sub)
//		{
//		String[] sp=main.split(" ");
//		String[] sp2=sub.split(" ");
//		boolean b=true;
//		for (int i = 0; i <sp.length; i++) 
//		{
//		
//				
//				if(sub.equals(sp[i]))
//				{
//					return true;
//					
//				}
//			   			
//		}
//		return false;
//	}
//		
//		//System.out.println(substringChek(main,sub));
//		
		
	

	 static boolean substringChek(String main, String sub) 
	 {
		char[] ch=main.toCharArray();
		char[] ch2=sub.toCharArray();
		for (int i = 0; i < ch.length; i++) 
		{
			int k=i;
			int j=0;
						
			while(k<ch.length&&j<ch2.length&&ch[k]==ch2[j])
			{
				k++;
				j++;
			}
		
			if(j==ch2.length&&(i==0||ch[i-1]==' ')&&
					(k==ch.length||ch[k]==' '
					))
			{
				return true;
			}
		}
			
		 return false;
	 }
}
