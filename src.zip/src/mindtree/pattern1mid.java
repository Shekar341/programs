package mindtree;

public class pattern1mid 
{
	public static void main(String[] args)
	{	
	int row=6;
	for(int i=1;i<=row;i++)
	{
		for(int j=1;j<=row+1;j++)
		{
			
				if(i%2!=0)
				{
					if(j<=row)
					{
						System.out.print(i);
					}
					else
					{
						System.out.print(i+1);
					}
					
				}
				else
				{
					if(j==1)
					{
					System.out.print(i+1);
					}
					else
					{
						System.out.print(i);
					}
				}
			
			}
		System.out.println();
}
	}
}
