package StringExp;

public class RetriveSpecialChar
{
	public static void main(String[] args)
	{
		String st="welcome(]to jspid%er";
		specialChar(st);
		
	}

 static void specialChar(String st) 
 {
	 String res="";
	char[] ch=st.toCharArray();
	for (int i = 0; i < ch.length; i++) 
	{
		if(ch[i]>=27&&ch[i]<=42)
		{
			
		res+=ch[i];	
		}
	
		
	}
		System.out.println(res);
 }

}
