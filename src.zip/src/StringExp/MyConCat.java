package StringExp;

public class MyConCat
{
	public static void main(String[] args)
	{
		String st="java";
		String st2="sql";
		MyConCat(st,st2);
	}

	 static void MyConCat(String st, String st2) 
	 {		char[] ch=st.toCharArray();
		char[] ch2=st2.toCharArray();
		char[] ch3=new char[ch.length+ch2.length];
		int k=0;
		for (int i = 0; i < ch.length; i++) 
		{
			ch3[k]=ch[i];
			k++;
		}
		for (int j= 0; j < ch2.length; j++) 
		{
			ch3[k]=ch2[j];			k++;
		}
		
		System.out.println(ch3);
		
	}

}
