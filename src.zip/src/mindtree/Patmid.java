package mindtree;

public class Patmid 
{
	public static void main(String[] args) 
	{
		int k=1;
		int a[][]=new int[6][6];
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 1; j < a.length-1; j++) 
			{
				a[i][j]=k;
				
			}
			k++;
			if(a[i][1]%2==0)
			{
				a[i][0]=a[i][1]+1;
				a[i][a.length-1]=a[i][a.length-2];
			}
			else
			{
				a[i][0]=a[i][1];
				a[i][a.length-1]=a[i][a.length-2]+1;
			}
		}
		// print array
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println(" ");
		}
	}
}
