package Arrays;

public class Distict 
{
	public static void main(String[] args) 
	{
		int[] a={1,2,1,2,2,2,2,5,5,5,4,1,1,1,1,1,7,8};
		{
			for (int i = 0; i < a.length; i++) 
			{
				int t=0;
				for (int j = 0; j < a.length; j++) 
				{
					if(a[i]==a[j])
					{
						t++;
					}
				}
				if(t==1)
				{
					System.out.print(a[i]+" ");
					
				}
				
			}
			
		}
		
	}

}
