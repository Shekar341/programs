package mindtree;

public class MindTree4 
{
	public static void main(String[] args) 
	{
		int num=3;
		for (int i = 1; i <=4; i++) 
		{
			for (int j = 1; j <=4-i; j++) 
			{
				System.out.print(" ");
				
			}
			for (int j = 1; j <=i; j++) 
			{
				System.out.print(" "+num);
			}
			num++;
			System.out.println();
		}
		num=num-1;
		for (int i =4; i >=1; i--) 
		{
			for (int j = 1; j <=4-i; j++)
			{
				System.out.print(" ");
			}
			for (int j = 1; j <=i; j++) 
			{
				System.out.print(" "+num);
			}
			num--;
			System.out.println();
		}
		
	}

}
