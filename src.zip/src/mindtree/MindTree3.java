package mindtree;

public class MindTree3 
{
	public static void main(String[] args)
	{
		int num=4,n=5;
		for (int i = 1; i <=n; i++) 
		{
			for (int j = 1; j <=n; j++)
			{
				if(i<5&&j==n/2+1)
				{
					System.out.print(num--);
				}
				else
				{
					System.out.print(n-1);
				}
			}
			System.out.println(" ");
		}
	}

}
