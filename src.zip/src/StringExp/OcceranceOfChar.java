package StringExp;

public class OcceranceOfChar 
{
	public static void main(String[] args)
	{
		
		
		
		String st="java is good";
		char[] ch=st.toCharArray();
		int[] a=new int[128];
		for (int i = 0; i < ch.length; i++) 
		{
			a[ch[i]]++;
		}
		for (int i = 0; i < ch.length; i++)
		{
			if(a[ch[i]]>0)
			{
				System.out.println(ch[i]+" Occred "+a[ch[i]]+" times");
				a[ch[i]]=0;
			}
			
		}
	}

}
