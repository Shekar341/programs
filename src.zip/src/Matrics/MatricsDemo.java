package Matrics;

public class MatricsDemo 
{
	public static void main(String[] args) 
	{
		int[][] a={{1,2,3},{4,5,6},{7,8,9}};
		display(a);
		//transpose(a);
		d180left(a);
		display(a);
	}

 static void rowRevers(int[][] a) 
 {
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a[i].length/2; j++) 
			{
				int t=a[i][j];
				a[i][j]=a[i][a[i].length-1-j];
				a[i][a[i].length-1-j]=t;
			}
		}
						
}
 static void ColumRevers(int[][]a)
	{
		for (int i = 0; i < a.length/2; i++) 
		{
			for (int j =0; j<a.length; j++) 
			{
				int t=a[i][j];
				a[i][j]=a[a[i].length-1-i][j];
				a[a[i].length-1-i][j]=t;
			}
		}
	
	}

static void transpose(int[][] a) 
 {
		for (int i = 0; i < a.length; i++) 
		{
			for (int j =i+1; j < a.length; j++)
			{
				int t=a[i][j];
				a[i][j]=a[j][i];
				a[j][i]=t;
			}
			
			
		}
		
 }
static void d90left(int[][] a)
{
	transpose(a);
	ColumRevers(a);
}
static void d90right(int[][] a)
{
	transpose(a);
	rowRevers(a);
}
static void d180right(int[][]a)
{
	d90right(a);
	d90right(a);
}
static void d180left(int[][]a)
{
	d90left(a);
	d90left(a);
}

static void display(int[][] a) 
{
	 for (int i = 0; i < a.length; i++) 
	{
		 for (int j = 0; j < a[i].length; j++) 
		 {
			 System.out.print(a[i][j]+" ");
		 }
		System.out.println();
	}
		System.out.println();
		
}
 

}
