package StringExp;

public class Panagram 
{
		//The quick brown fox jumps over the lazy dog.
		//Pack my box with five dozen liquor jugs.
		public static void main(String[] args) 
		{
			String st="The quick brown fox#%#^#$^%Jumps over the laZy dog";
			isPanagram(st);
		}
		private static void isPanagram(String st)
		{
			int [] a=new int[26];
			int count=0;
			char[] ch=st.toCharArray();
			for (int i = 0; i < ch.length; i++) 
			{
				if(ch[i]>=97&&ch[i]<=122)
				{
					if(a[ch[i]-97]==0)
					{
						count++;
					}
					a[ch[i]-97]=1;
				}
				else if(ch[i]>=65&&ch[i]<=90)
				{
					if(a[ch[i]-65]==0)
					{
					count++;	
					}
					
					a[ch[i]-65]=1;
				}
			}
			if(count==26)
			{
				System.out.println("String is Panagram");
			}
			else
			{
				System.out.println("String is not Panagram");
			}
		}
	
}
