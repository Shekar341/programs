package StringExp;

public class NUmbersCharSpeci 
{
	public static void main(String[] args) 
	{
		String st="shekarbn143@gmail.com";
		mymethod(st);
	}

 static void mymethod(String st) 
	{
	String charactors="";
	String number="";
	String specialchar="";
	 char[] ch=st.toCharArray();
	 for (int i = 0; i < ch.length; i++) 
	 {
		 if(ch[i]>='a'&&ch[i]<='z'||ch[i]>='A'&&ch[i]<='Z')
		 {
			 charactors+=ch[i];
		 }
		 else if(ch[i]>='0'&&ch[i]<='9')
		 {
			 number+=ch[i];
		 }
		 else
		 {
			 specialchar+=ch[i];
		 }
	}
	 System.out.println(charactors);
	 System.out.println(number);
	 System.out.println(specialchar);
	
	}

}
