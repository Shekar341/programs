
public class DecToHex 
{
	public static void main(String[] args) 
	{
		int n=500;
		String st="";
		while(n>0)
		{
			int r=n%16;
			if(r>9&&r<16)
			{
				st=(char)(r+55)+st;
			}
			else
			{
			st=r+st;
			}
			n=n/16;
		}
		System.out.println(st);	
	}
}
