import java.util.Scanner;


public class EvenOrOdd 
{
	public static void main(String[] args) 
	{
	Scanner sc =new Scanner(System.in);
		System.out.println("Enter The Number");
	int n=sc.nextInt();
	int t=n;
	while(n>0)
	{
		n=n-2;
	}
	
	
	if(n==0)
	{
		System.out.println(t+" Even number");
	}
	else
	{
		System.out.println(t+" odd number");
	}
	}

}
