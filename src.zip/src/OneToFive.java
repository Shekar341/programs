
public class OneToFive 
{
	public static void main(String[] args) 
	{
		print(1);
	}

	private static void print(int n) 
	{
		if(n<=5)
		{ 
			print(n+1);
			System.out.println( n);
			
		}
		
	}

}
