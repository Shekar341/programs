
public class Fact 
{
	public static void main(String[] args) 
	{
		//Fact f=new Fact();
		System.out.println(factnum(40));
		
	}

	 static double factnum(double n) 
	{
		if(n==0||n==1)
		{
			return 1;
		}
		return n*factnum(n-1);
		
	}

}
