package Arrays;

public class MissingElement 
{
	public static void main(String[] args) 
	{
		int[] a={1,2,3,4,5,8,7,9};
		int n=a.length;
		int total=(n+1)*(n+2)/2;
		for (int i = 0; i < a.length; i++) 
		{
			total=total-a[i];
		}
		System.out.println("missing Element= "+total);
	}
		
}
