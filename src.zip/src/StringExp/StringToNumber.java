package StringExp;

public class StringToNumber 
{
	public static void main(String[] args) 
	{
		String st="jspiders143@gmail.com";
		char[] ch=st.toCharArray();
		//int num=0;
		int number=0;
		for (int i = 0; i < ch.length; i++) 
		{
			if(ch[i]>='0'&&ch[i]<='9')
			{				
				number=(number*10)+ch[i]-48;
				//num=(num*10)+number;
			}
			
		}
		System.out.println(number);
	}

}
