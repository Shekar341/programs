package pattren;

public class Pattren1 
{
	public static void main(String[] args) 
	{
		int n=5;
		//char ch='A';
		
		for (int i =1; i <=n; i++)
		{
			char ch='A';
			for (int j =1; j <=n-i; j++) 
			{
				System.out.print(" ");
			}
			for (int j = 1; j<2*i; j++) 
			{
			
				if(j<i)
				System.out.print(ch++); 
				else
			    System.out.print(ch--);
			}
									
			System.out.println();
		}
		
	}

}
