package StringExp;

public class OcceranceOfchar2logic 
{
	public static void main(String[] args) 
	{
		String st="java is GGood";
		int n=st.length();
		char[] ch=st.toCharArray();
		for (int i = 0; i <n; i++) 
		{
			int count=1;
			for (int j = i+1; j <n; j++) 
			{
				if(ch[i]==ch[j]||ch[i]==ch[j]+32
						||ch[i]==ch[j]-32)
				{
					count++;
					int k=j;
					while(k<n-1)
					{
						ch[k]=ch[k+1];
						k++;
					}
					j--;
					n--;
				}
				
			}
			System.out.println(ch[i]+" occerd "+count+" times ");
		}
		
	}

}
