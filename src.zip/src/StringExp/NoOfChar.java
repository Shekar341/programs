package StringExp;

public class NoOfChar
{
	public static void main(String[] args) 
	{
		String st="Java Is GooD";
		//myToUpperCase(st);
		//myToLowerCase(st);
		myUTL(st);
	}
	static void myUTL(String st) 
	{
		 char[] ch=st.toCharArray();
		 for (int i = 0; i < ch.length; i++) 
			{
				if(ch[i]>='a'&&ch[i]<='z')
				{
				ch[i]=   (char)(ch[i]-32);
				}
				else if(ch[i]>='A'&&ch[i]<='Z')
				{
				ch[i]=   (char)(ch[i]+32);
				}
			}
		 System.out.print(ch);
		
	}

	static void myToUpperCase(String st) 
	{
		char[] ch=st.toCharArray();
		int count=0;
		for (int i = 0; i < ch.length; i++) 
		{
			if(ch[i]>='a'&&ch[i]<='z')
			{
			ch[i]=   (char)(ch[i]-32);
			}
		}
		System.out.print(ch);
	}
	static void myToLowerCase(String st) 
	{
		char[] ch=st.toCharArray();
		int count=0;
		for (int i = 0; i < ch.length; i++) 
		{
			if(ch[i]>='A'&&ch[i]<='Z')
			{
			ch[i]=   (char)(ch[i]+32);
			}
		}
		System.out.print(ch);
	}
		
	
}


