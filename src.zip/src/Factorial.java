
public class Factorial
{
	public static void main(String[] args)
	{
		int n=78;
		int f=1;
		
		for (int i = 1; i <=n; i++) 
		{
			f=f*i;
		}
		System.out.println(f);
		
	}

}
