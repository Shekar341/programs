
public class DecToBin 
{
	public static void main(String[] args) 
	{
		decTobin(9);
		
	}

	 static void decTobin(int n) 
	{
		 String st="";
		while(n>0)
		{
			int r=n%8;
			st=r+st;
			n=n/8;
		}
		System.out.println(st);
	}

}
