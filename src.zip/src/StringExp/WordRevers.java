package StringExp;

public class WordRevers 
{
	public static void main(String[] args) 
	{
		String st="Rama went to Qspider";
		char[] ch=st.toCharArray();
		String res="";
		for (int i = ch.length-1; i>=0; i--) 
		{
			int k=i;
			while(i>=0&&ch[i]!=' ')
			{
				i--;
			}
			int j=i+1;
			while(j<=k)
			{
				res+=ch[j];
				j++;
			}
			if(i>=0&&ch[i]==' ')
			{
				res+=ch[i];
			}
		}
		System.out.println(res);
	}
}
