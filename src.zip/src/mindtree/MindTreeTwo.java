package mindtree;

public class MindTreeTwo 
{
	public static void main(String[] args) 
	{
		int n=4,k=1,l=1;
		for (int i = 1; i <=n; i++) 
		{
			for (int j = 1; j <2*i; j++) 
			{
				if(j%2==0)
				{
				System.out.print("*");
				}
				else
				{
					if(i%2!=0)
					{
					System.out.print(k);
					k++;
					l=k+i;
					}
					else
					{
						System.out.print(l--);
						k++;
					}
				}
			}
			System.out.println();
		}
		
	}

}
