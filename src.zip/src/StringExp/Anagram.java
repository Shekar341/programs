package StringExp;

public class Anagram 
{
	public static void main(String[] args)
	{
		String st="Keep Dog        gg";
		String st2="peek god   gg";
		isAnagram(st,st2);
	}
	private static void isAnagram(String st, String st2) 
	{
		String s1=removeSpace(st).toLowerCase();
		 s1=sort(s1);
		
		 String s2=removeSpace(st2).toLowerCase();
		 s2=sort(s2);
		 
		if(s1.equals(s2))
		{
			System.out.println("String are Anagram");
		}
		else
		{
			System.out.println("String are not Anagram");
		}
	}
	
	private static String sort(String st) 
	{
		char[] ch=st.toCharArray();
		for (int i = 0; i < ch.length; i++) 
		{
			for (int j =i+1; j < ch.length; j++) 
			{
				if(ch[i]>ch[j])
				{
					char temp=ch[i];
					ch[i]=ch[j];
					ch[j]=temp;
				}
			}
	}
		return new String(ch);
  }
	static String removeSpace(String st)
	{
		char[] ch=st.toCharArray();
		st="";
		for (int i = 0; i < ch.length; i++) 
		{
			if(ch[i]!=' ')
			{
				st=st+ch[i];
			}
		}
		return st;
	}
}
