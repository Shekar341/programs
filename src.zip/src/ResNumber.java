import java.util.Scanner;


public class ResNumber 
{
	public static void main(String[] args) 
	{
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter The Number");
//		resNum(sc.nextInt());
	int n=2;
	int pow=3;
	int p=1;
	for (int i = 1; i <=pow; i++) 
	{
		p=p*n;
	}
	System.out.println(p);
	}

	private static void resNum(int num) 
	{
		int temp=num;
		int res=0;
		while(num>0)
		{			 
			int r=num%10;
			 res=(res*10)+r;
			 num=num/10;
		 }
		if(temp==res)
		{
			System.out.println("Number is palindrome");
		}
		else
		{
			System.out.println("Number is not palindrome");
		}
	}

}
